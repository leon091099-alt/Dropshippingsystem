/**
 * Registriert die benötigten Shopify-Webhooks auf BASE_URL/webhooks/shopify.
 * Einmalig nach dem Deployment ausführen:  npm run register-webhooks
 * Alternative: Webhooks in der shopify.app.toml der App deklarieren (dann entfällt dieses Skript).
 */
import { loadConfig } from '../src/config.js';
import { RealShopifyGateway } from '../src/shopify/gateway.js';
import { WEBHOOK_TOPICS } from '../src/webhooks.js';

const cfg = loadConfig();
const gw = new RealShopifyGateway(cfg);
const uri = `${cfg.BASE_URL}/webhooks/shopify`;
for (const topic of WEBHOOK_TOPICS) {
  try {
    const id = await gw.registerWebhook(topic, uri);
    console.log(`✓ ${topic} -> ${uri} (${id})`);
  } catch (e) {
    console.error(`✗ ${topic}: ${e instanceof Error ? e.message : e}`);
  }
}
