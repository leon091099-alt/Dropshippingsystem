import { Hono } from 'hono';
import { HTTPException } from 'hono/http-exception';
import type { Deps } from './deps.js';
import { log } from './log.js';
import { adminRoutes } from './routes/admin.js';
import { publicRoutes } from './routes/public.js';
import { retailerPage } from './routes/retailer-page.js';

export function createApp(d: Deps) {
  const app = new Hono();
  app.get('/', (c) => c.redirect('/admin'));
  app.route('/', publicRoutes(d));
  app.route('/', retailerPage(d));
  app.route('/', adminRoutes(d));
  app.onError((err, c) => {
    if (err instanceof HTTPException) return err.getResponse();
    log.error('unbehandelter fehler', { path: c.req.path, error: String(err) });
    return c.text('Interner Fehler', 500);
  });
  return app;
}
