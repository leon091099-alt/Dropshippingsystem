import { createHmac, timingSafeEqual } from 'node:crypto';
import type { Catalog } from './catalog.js';
import { log } from './log.js';
import type { ShopifyGateway } from './shopify/types.js';

export const WEBHOOK_TOPICS = ['INVENTORY_LEVELS_UPDATE', 'ORDERS_CREATE', 'PRODUCTS_UPDATE'] as const;

export function verifyHmac(rawBody: string, hmacHeader: string | undefined, secret: string): boolean {
  if (!hmacHeader || !secret) return false;
  const digest = createHmac('sha256', secret).update(rawBody, 'utf8').digest();
  const given = Buffer.from(hmacHeader, 'base64');
  return given.length === digest.length && timingSafeEqual(given, digest);
}

const norm = (s: unknown) => String(s ?? '').trim().toLowerCase().replace(/\s+/g, ' ');

/** B2B-Shop-Bestellung mit abweichender Lieferadresse = Dropship. */
export function isB2bDropship(order: any): boolean {
  if (!order?.company?.id) return false;
  const tags = String(order.tags ?? '').split(',').map((t) => t.trim());
  if (tags.includes('dropship')) return false;
  const s = order.shipping_address, b = order.billing_address;
  if (!s || !b) return false;
  return norm(s.address1) !== norm(b.address1) || norm(s.zip) !== norm(b.zip) || norm(s.name) !== norm(b.name);
}

export class WebhookHandler {
  private seen = new Map<string, number>();

  constructor(
    private readonly catalog: Catalog,
    private readonly shopify: ShopifyGateway,
    private readonly scheduleProductRefresh: () => void,
  ) {}

  /** true = verarbeitet, false = Duplikat */
  async handle(topic: string, webhookId: string | undefined, payload: any): Promise<boolean> {
    if (webhookId) {
      if (this.seen.has(webhookId)) return false;
      this.seen.set(webhookId, Date.now());
      if (this.seen.size > 5000) {
        const cutoff = Date.now() - 3600_000;
        for (const [k, t] of this.seen) if (t < cutoff) this.seen.delete(k);
      }
    }

    switch (topic) {
      case 'inventory_levels/update': {
        const ok = this.catalog.applyInventoryLevel(String(payload.inventory_item_id), String(payload.location_id), Number(payload.available ?? 0));
        if (!ok) log.info('inventory webhook für artikel außerhalb des feeds', { item: payload.inventory_item_id });
        break;
      }
      case 'orders/create': {
        if (isB2bDropship(payload)) {
          await this.shopify.addOrderTags(payload.admin_graphql_api_id, ['dropship', 'kanal-b2b_shop']);
          log.info('b2b-shop-bestellung als dropship markiert', { order: payload.name });
        }
        break;
      }
      case 'products/update':
        this.scheduleProductRefresh();
        break;
      default:
        log.warn('unbekanntes webhook-topic', { topic });
    }
    return true;
  }
}
