# PearlRhine Dropship-Gateway

Eine Anwendung, die zwischen unserem Shopify-Shop und den Händlern sitzt:

- **Feeds** pro Händler: Bestand (alle 5–15 Min. abrufbar) und Produktdaten, als CSV, XML oder JSON
- **Bestellungen** per REST-API oder CSV-Upload → werden als Shopify-Order (Draft Order → Order) angelegt
- **B2B-Shop-Bestellungen** mit abweichender Lieferadresse werden automatisch als `dropship` markiert
- **Status & Tracking** zurück an den Händler (API, Händlerseite, Tracking-CSV; Versandmail kommt von Shopify)
- **Admin** unter `/admin`: Händler verwalten, Prüfliste, Storno-Aufgaben

Shopify bleibt die einzige Wahrheit. Die App hält nur eine SQLite-Datei (Händler-Zugänge, Bestell-Log, Bestands-Snapshot).

## Aufbau

```
src/
  server.ts            Start, Hintergrundjobs (Bestand alle 5 Min., Produkte stündlich)
  app.ts               Routen zusammenführen
  config.ts            alle Einstellungen aus .env
  catalog.ts           Snapshot, Bestandsregel, EK-Berechnung
  feeds.ts             CSV/XML/JSON-Ausgabe
  orders/              Prüfung, Anlage in Shopify, Status, CSV-Import
  retailers.ts         Händler, Feed-Token, API-Keys (gehasht)
  webhooks.ts          HMAC-Prüfung, inventory_levels/update, orders/create, products/update
  shopify/             GraphQL-Client, Gateway (real + Mock)
  routes/              öffentliche Routen, Händlerseite, Admin
shopify/packing-slip.liquid   Lieferschein-Vorlage mit Neutralversand
scripts/register-webhooks.ts  Webhooks einmalig registrieren
```

## Bestandsregel

`angezeigt = min(verfügbar − STOCK_BUFFER, STOCK_CAP)`, nie unter 0 (Standard: Puffer 2, Deckel 20).
Verfügbar = Summe „available“ über alle Locations bzw. nur `DROPSHIP_LOCATION_IDS`.
Aktualisierung: Webhook patcht den Snapshot sofort, zusätzlich Vollabgleich alle 5 Min.; nach jeder angelegten Order wird lokal reserviert.

## EK (Händler-Einkaufspreis netto)

Reihenfolge:
1. Metafeld `dropship.ek` an Variante oder Produkt (netto)
2. B2B-Preisliste `B2B_PRICE_LIST_ID` (wird bei gesetztem Steuer-Flag in netto umgerechnet)
3. Fallback: UVP netto × (1 − `DEFAULT_EK_DISCOUNT_PERCENT`)

In der Draft Order setzt die App den EK als prozentualen Zeilenrabatt. Ausnahme: Händler ist mit einer
B2B-Firma verknüpft **und** eine Preisliste ist gesetzt → Shopify wendet den Katalogpreis selbst an.
**Im Pilot prüfen**, dass dabei kein doppelter Rabatt entsteht.

## Optionale Metafelder (Namespace `dropship`, Produkt oder Variante)

| Key | Inhalt |
| --- | --- |
| `ek` | Händler-EK netto (Dezimalzahl) |
| `mpn` | Hersteller-Artikelnummer |
| `eta` | Nachschubtermin (Text/Datum) |
| `ausgelaufen` | `true` = nicht mehr bestellbar |
| `gpsr_hersteller`, `gpsr_eu_verantwortlicher`, `sicherheitshinweise` | GPSR-Angaben |
| `weee_reg` | WEEE-Registrierungsnummer |
| `datenblatt_url`, `anleitung_url` | PDFs |

Produkte kommen in die Feeds, wenn sie `PRODUCT_QUERY` erfüllen (Standard: Tag `dropship`, Status aktiv).

## Einrichtung

### 1. Shopify-App
Seit 01.01.2026 lassen sich keine neuen „Legacy Custom Apps“ im Shop-Admin anlegen. Zwei Wege:
- **Vorhandenes Admin-API-Token** weiterverwenden → `SHOPIFY_ADMIN_TOKEN`
- **Neue App im Dev Dashboard**, im eigenen Shop installieren → `SHOPIFY_CLIENT_ID` + `SHOPIFY_CLIENT_SECRET`.
  Die App holt sich das Token selbst (Client-Credentials-Grant, 24 h, automatische Erneuerung).

Benötigte Scopes: `read_products`, `read_inventory`, `read_locations`, `read_orders`, `write_orders`,
`write_draft_orders`, `read_draft_orders`, `read_companies`, `read_fulfillments`.

### 2. Server (ein VPS, z. B. Hetzner CX22)
```bash
cp .env.example .env        # ausfüllen
# Domain in Caddyfile eintragen, DNS auf den Server zeigen lassen
docker compose up -d --build
```
Webhooks einmalig registrieren (lokal mit gleicher .env):
```bash
npm ci && npm run register-webhooks
```
Backup: Ordner `./data` (eine SQLite-Datei) oder Server-Snapshot.

### 3. Shopify-Einstellungen
- Lieferschein-Vorlage: Inhalt von `shopify/packing-slip.liquid` einsetzen, mit Testbestellung prüfen.
- B2B-Firmen der Händler: „Allow customers to ship to any one-time address“ aktivieren, Zahlungsziel setzen.
- Externe Fulfiller: deren Neutralversand-Option prüfen (eigene Lieferscheine).

### 4. Händler anlegen
`/admin/retailers/new` → Zugangsdaten werden einmal angezeigt (API-Key) → Link zur Händlerseite schicken.
Neue Händler zuerst ohne „automatisch annehmen“ laufen lassen (jede Bestellung in der Prüfliste).

## API für Händler

Auth: `Authorization: Bearer dsk_…`

| Methode | Pfad | Zweck |
| --- | --- | --- |
| GET | `/api/stock` | Bestand JSON |
| POST | `/api/orders` | Bestellung anlegen (idempotent über `reference`) |
| GET | `/api/orders?days=30` | Bestellungen |
| GET | `/api/orders/{reference}` | Status + Tracking |
| POST | `/api/orders/{reference}/cancel` | Storno anfragen |

```json
POST /api/orders
{
  "reference": "A-1001",
  "shippingAddress": { "name": "Erika Musterfrau", "company": "", "address1": "Ringstraße 7",
                       "address2": "", "zip": "50667", "city": "Köln", "countryCode": "DE", "phone": "" },
  "lines": [{ "sku": "DF-TRIPOD-01", "quantity": 1 }],
  "note": ""
}
```
Antwort `201` (neu) bzw. `200` (bereits vorhanden), `422` bei Formfehlern.
Status: `accepted`, `on_hold`, `rejected`, `shipped`, `cancel_requested`, `cancelled`, `returned`.

Feeds: `/feed/{token}/stock.csv|xml|json`, `/feed/{token}/products.csv|xml|json` (max. 60 Abrufe/Min.).

## CSV-Bestellimport
Kopfzeile: `bestellnummer;sku;menge;name;firma;strasse;adresszusatz;plz;ort;land;telefon;notiz`
(englische Spaltennamen werden erkannt). Mehrere Zeilen mit gleicher Bestellnummer = eine Bestellung.

## Entwicklung
```bash
npm install
npm test                    # 22 Tests gegen Mock-Shopify
MOCK_SHOPIFY=true SHOPIFY_STORE=x.myshopify.com ADMIN_PASSWORD=geheim123 npm run dev
```

## Vor dem Livegang gegen einen Dev-Store prüfen
- GraphQL-Abfragen und Mutations (Schema-Version `SHOPIFY_API_VERSION`)
- `draftOrderComplete(paymentPending: true)` ist deprecated → Verhalten mit B2B-Zahlungsziel testen
- Katalogpreis vs. Zeilenrabatt bei verknüpfter B2B-Firma
- Lieferschein-Vorlage im Dropship-Fall
- Versandmail an die Händler-E-Mail
